import streamlit as st

import base64


def set_background(image_file):
    with open(image_file, "rb") as f:
        encoded_string = base64.b64encode(f.read()).decode()
    css = f"""
    <style>
    .stApp {{
        background-image: url("data:image/jpg;base64,{encoded_string}");
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

set_background("assets/Background.jpg")

st.set_page_config(
    page_title="Interactive Statistical Analysis",
    page_icon="📊",
    layout="wide"
)

col1, col2, col3 = st.columns([1, 3, 1])

with col2:
    st.markdown("""
    <h1 style='text-align: center; font-size: 90px; color: #9393F6;'>
    Colombo Stock Exchange
    </h1>
    """, unsafe_allow_html=True)

    st.markdown("""
    <h3 style='text-align: center; font-size: 50px; color: #6060CD;'>
    Annual Trading Statistics
    </h3>
    """, unsafe_allow_html=True)

st.markdown("<hr>", unsafe_allow_html=True)

with st.container(border=True):
    st.markdown("""         
    <div style=" font-size: 20px; padding:20px 20px 20px 50px;">
    <h3>Overview</h3>
    This dashboard presents a structured analysis of Colombo Stock Exchange annual trading data (2006–2022). 
    It integrates data preprocessing, panel regression modeling, and time series forecasting 
    to provide meaningful insights into company-level and market-level dynamics. <br><br>The platform is designed for analytical transparency, statistical rigor, and user-friendly exploration.

    </div>
    """, unsafe_allow_html=True)
        