import streamlit as st
import pandas as pd
import numpy as np

from data_loader import load_processed_data

# Wide layout for this page
st.set_page_config(page_title="Modelling", page_icon="📌", layout="wide")

st.markdown("""
<style>
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
div[data-testid="stMetric"] { background: rgba(255,255,255,0.03); padding: 12px; border-radius: 14px; }
</style>
""", unsafe_allow_html=True)

st.title("Market Analytics & Forecasting")

# -----------------------------
# Load processed dataset (shared)
# -----------------------------
@st.cache_data
def get_df():
    return load_processed_data()

df = get_df()

if df is None or not isinstance(df, pd.DataFrame):
    st.error("Processed dataset could not be loaded. Please check `data_loader.py` (it must return a DataFrame).")
    st.stop()

# Ensure Volatility exists
if "Volatility" not in df.columns and {"High_(Rs)", "Low_(Rs)"}.issubset(df.columns):
    df["Volatility"] = (df["High_(Rs)"] - df["Low_(Rs)"]).abs()

# Basic cleaning for modelling
df = df.dropna(subset=["Symbol", "Year"]).copy()
df["Year"] = df["Year"].astype(int)

tab1, tab2 = st.tabs(["Panel Regression", "Forecasting"])


# =========================================================
# TAB 1: Panel Regression (Professional, safe, organized)
# =========================================================
with tab1:
    with st.container(border=True):
        st.subheader("Panel Regression (Fixed Effects)")
        st.write(
            "We build this model to understand how trading indicators relate to changes in the selected outcome "
            "**within the same company over time**. The model controls for permanent firm differences and can also "
            "adjust for year-to-year market-wide shocks."
        )


        st.write(
            "This model helps us understand which trading indicators are associated with changes in the selected outcome "
            "(such as Turnover) **within the same company over time**. "
            "It controls for permanent differences between companies (e.g., company size or business type) "
            "and can also adjust for market-wide changes that affect all companies in a given year (e.g., crises, inflation)."
        )

    # -----------------------------
    # Controls + Filters (like Data page)
    # -----------------------------
    with st.container(border=True):
        st.markdown("### Controls")
   
        c1, c2, c3 = st.columns([1.4, 1.2, 1.4])

        if "GICS Industry Group" in df.columns:
            industries = sorted(df["GICS Industry Group"].dropna().unique().tolist())
            with c1:
                selected_industries = st.multiselect(
                    "Industry group (optional)",
                    options=industries,
                    default=[]
                )

                st.caption(
                "Tip: If the selected filter produces too few companies/years, the model cannot be estimated. "
                "Widen the year range or remove the industry filter."
            )
        else:
            selected_industries = []
            with c1:
                st.info("GICS Industry Group column not available.")


        with c2:
            y_min, y_max = int(df["Year"].min()), int(df["Year"].max())
            year_range = st.slider("Year range", y_min, y_max, (y_min, y_max))

        with c3:
            include_time_effects = st.checkbox("Adjust for economy-wide yearly changes", value=True)

            st.caption(
                "Examples include financial crises, policy changes, inflation, or other events "
                "that influenced the entire market in that year."
            )
        # Apply filters
        model_df = df[(df["Year"] >= year_range[0]) & (df["Year"] <= year_range[1])].copy()
        if selected_industries:
            model_df = model_df[model_df["GICS Industry Group"].isin(selected_industries)]

    # -----------------------------
    # Variable selection
    # -----------------------------
    
    with st.container(border=True):
        st.markdown("### Variable Selection")

        dep_candidates = [c for c in ["Turnover(Rs)", "Share_Volume", "Trade_Volume"] if c in model_df.columns]
        dep_var = st.selectbox("Outcome (dependent variable)", dep_candidates)

        indep_options = ["Volatility", "Share_Volume", "Trade_Volume", "Open_(Rs)", "Close_(Rs)", "High_(Rs)", "Low_(Rs)"]
        indep_vars = st.multiselect(
            "Predictors (independent variables)",
            options=[c for c in indep_options if c in model_df.columns],
            default=[c for c in ["Volatility", "Trade_Volume"] if c in model_df.columns]  # keep a safer default
        )

        log_transform = st.checkbox("Log-transform the outcome (recommended for skewed data)", value=True)

    st.divider()

    # -----------------------------
    # Model specification (auto-updating)
    # -----------------------------
   
    
    st.markdown("### Model Specification (What we estimate)")

   
    # Pretty names for display
    pretty = {
        "Turnover(Rs)": "Turnover",
        "Trade_Volume": "Trade Volume",
        "Share_Volume": "Share Volume",
        "Open_(Rs)": "Open Price",
        "Close_(Rs)": "Close Price",
        "High_(Rs)": "High Price",
        "Low_(Rs)": "Low Price",
        "Volatility": "Volatility",
        "const": "Intercept"
    }

    def p(name: str) -> str:
        return pretty.get(name, name)

    # Left-hand side
    lhs = f"log({p(dep_var)} + 1)" if log_transform else p(dep_var)

    # Right-hand side predictors
    if indep_vars:
        rhs_terms = " + ".join([f"β{i+1}·{p(v)}" for i, v in enumerate(indep_vars)])
    else:
        rhs_terms = "..."

    # Fixed effects terms
    entity_term = " + α(company)"
    time_term = " + γ(year)" if include_time_effects else ""

    equation = f"**{lhs} = β₀ + {rhs_terms}{entity_term}{time_term} + ε**"

    st.markdown(equation)

    # Plain-language explanation (non-technical)
    
    if log_transform:
        st.caption(
            "Because the outcome is log-transformed, coefficients are approximately interpreted as percentage changes "
            "in the outcome for a one-unit change in the predictor (holding other factors constant)."
        )

        
        # Optional: show exact predictors list clearly
        st.markdown("**Selected predictors:**")
        st.write('- ',", ".join(indep_vars) if indep_vars else "No predictors selected.")

    # -----------------------------
    # Pre-checks (assumption-ish checks that prevent nonsense)
    # Only BLOCK if model cannot be estimated.
    # -----------------------------
    with st.container(border=True):
        st.markdown("### Data Readiness Check")

        needed_cols = ["Symbol", "Year", dep_var] + indep_vars
        missing_cols = [c for c in needed_cols if c not in model_df.columns]

        if missing_cols:
            st.error(f"Missing required columns for this model: {missing_cols}")
            st.stop()

        if len(indep_vars) == 0:
            st.warning("Select at least one predictor to run the panel regression.")
            st.stop()

        panel_raw = model_df.dropna(subset=needed_cols).copy()

        n_obs = panel_raw.shape[0]
        n_entities = panel_raw["Symbol"].nunique()
        n_years = panel_raw["Year"].nunique()

        kpi1, kpi2, kpi3, kpi4 = st.columns(4)
        kpi1.metric("Observations", f"{n_obs:,}")
        kpi2.metric("Companies", f"{n_entities:,}")
        kpi3.metric("Years", f"{n_years:,}")
        kpi4.metric("Predictors", f"{len(indep_vars):,}")

    can_run = (n_obs >= 30) and (n_entities >= 2) and (n_years >= 3) and (len(indep_vars) >= 1)

    if n_obs == 0:
        st.error("No data left after filtering and removing missing values. Expand filters or choose different variables.")
        st.stop()

    if n_entities < 2 or n_years < 3:
        st.error(
            "Not enough panel structure after filtering. "
            "Use a wider year range and/or remove industry filter."
        )
        st.stop()

    # Optional: quick multicollinearity warning (non-blocking)
    numeric_subset = panel_raw[indep_vars].select_dtypes(include=[np.number]).copy()
    if numeric_subset.shape[1] >= 2:
        corr_max = numeric_subset.corr().abs().where(lambda x: np.triu(np.ones(x.shape), k=1).astype(bool)).max().max()
        if pd.notna(corr_max) and corr_max > 0.90:
            st.warning(
                "Some predictors are highly correlated (|corr| > 0.90). "
                "This can make p-values unstable. Consider removing one of the correlated variables."
            )

    # Remove constant predictors (no variation after filtering)
    constant_cols = [c for c in indep_vars if panel_raw[c].nunique(dropna=True) <= 1]
    if constant_cols:
        st.warning(f"Removed predictors with no variation in the filtered data: {constant_cols}")
        indep_vars = [c for c in indep_vars if c not in constant_cols]

    if len(indep_vars) == 0:
        st.error("No valid predictors left after filtering (all were constant). Choose different predictors or widen filters.")
        st.stop()
        

    st.divider()

    # -----------------------------
    # Fit model
    # -----------------------------
    st.markdown("### Estimate Model")

    from linearmodels.panel import PanelOLS, RandomEffects
    import statsmodels.api as sm
    from scipy import stats
    from statsmodels.stats.outliers_influence import variance_inflation_factor

    run_panel = st.button("Run Panel Regression", key="run_panel", disabled=not can_run)

    if not can_run:
        st.info("Adjust filters/variables until the dataset has enough observations, companies, and years to run the model.")
    
    if run_panel:
        with st.spinner("Estimating panel model..."):
            panel = panel_raw.copy()
            panel["Year"] = panel["Year"].astype(int)
            panel = panel.set_index(["Symbol", "Year"])

            y = panel[dep_var].astype(float)
            if log_transform:
                y = np.log(y + 1)

            X = panel[indep_vars].astype(float)
            X = sm.add_constant(X)

            # Use clustered SE by entity (good for panel data)
            fe_model = PanelOLS(y, X, entity_effects=True, time_effects=include_time_effects)

            try:
                fe_res = fe_model.fit(cov_type="clustered", cluster_entity=True)
            except Exception as e:
                st.warning("Clustered SE failed; switching to robust SE.")
                st.code(str(e))
                fe_res = fe_model.fit(cov_type="robust")
        
            
        # -----------------------------
        # Results: KPIs
        # -----------------------------
        
        with st.container(border=True):
            st.markdown("### Key Results")
        

            r1, r2, r3, r4 = st.columns(4)
            r1.metric("Observations", f"{int(fe_res.nobs):,}")
            r2.metric("R² (within)", f"{fe_res.rsquared_within:.4f}")
            r3.metric("R² (overall)", f"{fe_res.rsquared_overall:.4f}")
            r4.metric("Model p-value", f"{fe_res.f_statistic.pval:.4f}" if fe_res.f_statistic is not None else "—")

            st.markdown("### Model Fit Explanation")

            st.write(
                f"""
                **R² (within)** = {fe_res.rsquared_within:.4f}  
                → This measures how much of the variation *within the same company over time* is explained by the model.

                **R² (overall)** = {fe_res.rsquared_overall:.4f}  
                → This measures how much of the total variation in the dataset is explained by the model.

                **Model p-value**  
                → Tests whether the predictors jointly explain the outcome.  
                A value below 0.05 suggests the model is statistically meaningful overall.
                """
            )


        
        # -----------------------------
        # Results: Coefficient table
        # -----------------------------
        
        with st.container(border=True):
            st.markdown("### Coefficient Table")
                
            

            ci = fe_res.conf_int()
            coef_table = pd.DataFrame({
                "Variable": fe_res.params.index,
                "Coefficient": fe_res.params.values,
                "Std. Error": fe_res.std_errors.values,
                "t-stat": fe_res.tstats.values,
                "p-value": fe_res.pvalues.values,
                "CI Lower": ci.iloc[:, 0].values,
                "CI Upper": ci.iloc[:, 1].values,
            })

            st.dataframe(
                coef_table.style.format({
                    "Coefficient": "{:.8f}",
                    "Std. Error": "{:.8f}",
                    "t-stat": "{:.4f}",
                    "p-value": "{:.6f}",
                    "CI Lower": "{:.8f}",
                    "CI Upper": "{:.8f}",
                }),
                use_container_width=True
            )

            st.markdown("### How to Read the Coefficient Table")

            st.write(
                """
                - **Coefficient**: Shows how much the outcome changes when the predictor increases by one unit.
                - **Std. Error**: Measures uncertainty around the coefficient estimate.
                - **t-stat**: Indicates how strong the effect is relative to its uncertainty.
                - **p-value**: Shows whether the effect is statistically meaningful (below 0.05 is typically considered significant).
                - **Confidence Interval (CI)**: Range where the true effect is likely to lie.
                """
            )
            

        # -----------------------------
        # Estimated model (with coefficients)
        # -----------------------------
        with st.container(border=True):
            st.markdown("### Estimated Model (Fitted Equation)")
            
            # Pretty names (same mapping you used earlier)
            pretty = {
                "Turnover(Rs)": "Turnover",
                "Trade_Volume": "Trade Volume",
                "Share_Volume": "Share Volume",
                "Open_(Rs)": "Open Price",
                "Close_(Rs)": "Close Price",
                "High_(Rs)": "High Price",
                "Low_(Rs)": "Low Price",
                "Volatility": "Volatility",
                "const": "Intercept"
            }

            def p(name: str) -> str:
                return pretty.get(name, name)

            # Left-hand side
            lhs = f"log({p(dep_var)} + 1)" if log_transform else p(dep_var)

            # Get coefficients
            params = fe_res.params.copy()

            # Intercept / constant (may exist)
            b0 = float(params.get("const", 0.0))

            # Build RHS terms for selected predictors only
            terms = []
            for v in indep_vars:
                if v in params.index:
                    bv = float(params[v])
                    sign = "+" if bv >= 0 else "−"
                    terms.append(f" {sign} {abs(bv):.6g}·{p(v)}")

            # Add FE terms text
            fe_text = " + α(company)"
            fe_text += " + γ(year)" if include_time_effects else ""

            # Build final equation string
            rhs = f"{b0:.6g}" + "".join(terms) + fe_text + " + ε"
            st.markdown(f"**{lhs} = {rhs}**")

            # Add a simple interpretation note
            if log_transform:
                st.caption(
                    "Because the outcome is log-transformed, each coefficient can be read approximately as a percentage effect: "
                    "a 1-unit increase in a predictor changes the outcome by about 100×β percent (holding other factors constant)."
                )
            else:
                st.caption(
                    "Because the outcome is not log-transformed, coefficients represent unit changes in the outcome for a 1-unit change in the predictor "
                    "(holding other factors constant)."
                )

                    
            coef_table["Variable"] = coef_table["Variable"].replace({
                "const": "Intercept",
                "Trade_Volume": "Trade Volume",
                "Share_Volume": "Share Volume"
            })

            

        # -----------------------------
        # Practical interpretation
        # -----------------------------
        with st.container(border=True):
            st.markdown("### Practical Interpretation")

            sig = coef_table[
                (~coef_table["Variable"].str.lower().isin(["const", "intercept"])) &
                (coef_table["p-value"] < 0.05)
            ].copy()

            if sig.empty:
                st.info("No statistically significant predictors (p < 0.05) for the current selection.")
            else:
                for _, row in sig.iterrows():
                    b = float(row["Coefficient"])
                    var = row["Variable"]

                    if log_transform:
                        pct = 100 * b
                        direction = "increase" if pct > 0 else "decrease"
                        st.write(
                            f"When **{var}** increases by 1 unit, the outcome is expected to **{direction}** by about "
                            f"**{abs(pct):.3f}%**, holding other factors constant."
                        )
                    else:
                        direction = "increase" if b > 0 else "decrease"
                        st.write(
                            f"When **{var}** increases by 1 unit, the outcome is expected to **{direction}** by about "
                            f"**{abs(b):,.3f} units**, holding other factors constant."
                        )

            with st.expander("What is the Intercept (const)?"):
                st.write(
                    "The intercept is the model's baseline prediction when all predictors are zero. "
                    "In fixed-effects panel regression, the intercept is not usually interpreted on its own because "
                    "company-specific effects are included in the model."
                )
                        
            with st.expander("Explaination"):
                st.write(
                    "This model compares each company to itself over time. "
                    "So the results describe how the outcome tends to change **within the same company** when a predictor changes. "
                    "Company fixed effects remove differences such as firm size or industry structure that are stable over time. "
                    "If year effects are included, the model also controls for year-specific shocks (e.g., crises or policy changes)."
                )

        # -----------------------------
        # Diagnostics (optional, protected)
        # -----------------------------
        st.markdown("### Diagnostics")

        with st.expander("Multicollinearity check (VIF)"):

            try:
                # Exclude constant column
                X_no_const = X.loc[:, X.columns != "const"]

                vif_df = pd.DataFrame()
                vif_df["Variable"] = X_no_const.columns
                vif_df["VIF"] = [
                    variance_inflation_factor(X_no_const.values, i)
                    for i in range(X_no_const.shape[1])
                ]

                st.dataframe(vif_df, use_container_width=True)

                st.caption(
                    "VIF measures whether predictors are too strongly related to each other. "
                    "Values above 10 suggest problematic multicollinearity."
                )

            except Exception as e:
                st.warning(f"VIF could not be computed: {e}")

        with st.expander("Hausman Test (Fixed Effects vs Random Effects)"):

            st.caption(
                "This test helps decide whether the Fixed Effects model or the Random Effects model "
                "is more appropriate for the data."
            )

            # Initialize variables to avoid undefined warnings
            stat_val = None
            p_val = None

            try:
                # Estimate Random Effects model
                re_model = RandomEffects(y, X)
                re_res = re_model.fit(cov_type="robust")

                # Compute Hausman statistic
                b_diff = fe_res.params - re_res.params
                cov_diff = fe_res.cov - re_res.cov

                stat_val = float(b_diff.T @ np.linalg.pinv(cov_diff) @ b_diff)

                # Hausman statistic cannot be negative
                stat_val = max(stat_val, 0)

                df_h = int(len(b_diff))
                p_val = float(1 - stats.chi2.cdf(stat_val, df_h))

            except Exception as e:
                st.warning(f"Hausman test could not be computed for this specification: {e}")

            # Only print results if successfully computed
            if stat_val is not None and p_val is not None:

                st.write(f"**Test statistic (χ²)** = {stat_val:.4f}")
                st.write(f"**p-value** = {p_val:.4f}")

                if p_val < 0.05:
                    st.success(
                        "The test suggests that company-specific characteristics are correlated with the predictors. "
                        "Therefore, the Fixed Effects model is more appropriate."
                    )
                else:
                    st.info(
                        "The test suggests that company-specific characteristics are not strongly correlated with the predictors. "
                        "Therefore, the Random Effects model may also be acceptable."
                    )

                st.markdown("### What This Means in Plain Language")

                if p_val < 0.05:
                    st.write(
                        "Companies appear to have unique characteristics that influence the relationship being studied. "
                        "Because of this, comparing each company to itself over time (Fixed Effects) "
                        "is more reliable than treating company differences as random."
                    )
                else:
                    st.write(
                        "There is no strong evidence that company-specific differences distort the relationship. "
                        "So it may be reasonable to treat companies as randomly different from each other."
                    )
        with st.expander("Technical output (full summary)"):
            st.text(fe_res.summary)


# =========================================================
# TAB 2: Forecasting (Time Series)
# =========================================================
with tab2:
    st.subheader("Forecasting (Time Series)")
    st.caption(
        "This section checks whether the selected series is stationary (unit root test) and then produces a short-horizon forecast."
    )

    import plotly.graph_objects as go
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    from statsmodels.tsa.stattools import adfuller

    # ---------- Helper: Symbol -> Company name ----------
    name_map = (
        df[["Symbol", "Company_Name"]]
        .dropna()
        .drop_duplicates(subset=["Symbol"])
        .set_index("Symbol")["Company_Name"]
        .to_dict()
    )

    symbol_list = sorted(df["Symbol"].dropna().unique().tolist())

    def format_company(sym):
        nm = name_map.get(sym, "Unknown Company")
        return f"{sym} — {nm}"

    # ---------- Controls (card) ----------
    with st.container(border=True):
        c1, c2, c3 = st.columns([2.2, 1.4, 1.4])

        with c1:
            symbol = st.selectbox(
                "Select company",
                options=symbol_list,
                format_func=format_company
            )

        with c2:
            target = st.selectbox(
                "Forecast variable",
                ["Turnover(Rs)", "Share_Volume", "Trade_Volume"],
                index=0
            )

        with c3:
            horizon = st.slider("Forecast horizon (years)", 1, 10, 5)

        use_log_y = st.checkbox(
            "Use log scale for plots (helps when values are very skewed)",
            value=False
        )

    # ---------- Prepare time series ----------
    ts_df = (
        df[df["Symbol"] == symbol]
        .sort_values("Year")[["Year", target]]
        .dropna()
        .copy()
    )

    if ts_df.shape[0] < 6:
        st.warning("Not enough time points for forecasting. Select another company.")
        st.stop()

    ts_df["Year"] = ts_df["Year"].astype(int)
    ts = ts_df.set_index("Year")[target].astype(float)
    ts.index = ts.index.astype(int)

    # ---------- Tabs inside Forecasting ----------
    ft1, ft2, ft3 = st.tabs(["1) Series Overview", "2) Stationarity Check", "3) Forecast"])

    # =========================================================
    # TAB A: Series overview
    # =========================================================
    with ft1:
        with st.container(border=True):
            st.markdown("### Series Overview")

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=ts.index, y=ts.values,
                mode="lines+markers",
                name="Actual"
            ))

            fig.update_layout(
                title=f"{target} over time — {format_company(symbol)}",
                xaxis_title="Year",
                yaxis_title=target.replace("_", " "),
                template="plotly_dark",
                hovermode="x unified"
            )

            if use_log_y:
                fig.update_yaxes(type="log")

            st.plotly_chart(fig, use_container_width=True)

            st.caption(
                "Tip: If the line shows a strong upward/downward trend, the series may be non-stationary (unit root may exist). "
                "The stationarity test in the next tab checks this more formally."
            )

    # =========================================================
    # TAB B: Stationarity check (ADF)
    # =========================================================
    with ft2:
        with st.container(border=True):
            st.markdown("### Stationarity (Unit Root) Check — ADF Test")

            st.write(
                "We use the **Augmented Dickey-Fuller (ADF) test** to check whether the series is stationary.\n\n"
                "- **Stationary**: the series fluctuates around a stable average (good for many statistical models).\n"
                "- **Non-stationary (unit root)**: the series has a trend/level changes over time.\n"
            )

            # ADF Test
            try:
                adf_result = adfuller(ts.values, autolag="AIC")
                adf_stat = float(adf_result[0])
                p_value = float(adf_result[1])
                used_lag = int(adf_result[2])
                nobs = int(adf_result[3])
                crit = adf_result[4]
            except Exception as e:
                st.error("ADF test could not be computed for this series.")
                st.code(str(e))
                st.stop()

            k1, k2, k3, k4 = st.columns(4)
            k1.metric("ADF statistic", f"{adf_stat:.4f}")
            k2.metric("p-value", f"{p_value:.4f}")
            k3.metric("Lags used", f"{used_lag}")
            k4.metric("Observations", f"{nobs}")

            with st.expander("How to interpret this (simple)", expanded=True):
                st.write(
                    "**Decision rule:**\n"
                    "- If **p-value < 0.05**, we treat the series as **stationary**.\n"
                    "- If **p-value ≥ 0.05**, the series is likely **non-stationary (unit root exists)**.\n\n"
                    "A non-stationary series often has trends or persistent level shifts."
                )

            # Show conclusion + optional differenced plot
            if p_value < 0.05:
                st.success("✅ The series appears **stationary** (no strong evidence of a unit root).")
            else:
                st.warning("⚠ The series appears **non-stationary** (unit root likely present).")

                st.markdown("#### First Difference (Change from one year to the next)")
                st.caption(
                    "This shows year-to-year changes and is often closer to stationary. "
                    "We display it for understanding, but we will still forecast the original series for dashboard clarity."
                )

                d1 = ts.diff().dropna()

                fig_d = go.Figure()
                fig_d.add_trace(go.Scatter(
                    x=d1.index, y=d1.values,
                    mode="lines+markers",
                    name="Δ (difference)"
                ))
                fig_d.update_layout(
                    title=f"First Difference of {target} — {format_company(symbol)}",
                    xaxis_title="Year",
                    yaxis_title=f"Change in {target}",
                    template="plotly_dark",
                    hovermode="x unified"
                )
                st.plotly_chart(fig_d, use_container_width=True)

    # =========================================================
    # TAB C: Forecast
    # =========================================================
    with ft3:
        with st.container(border=True):
            st.markdown("### Forecast (Exponential Smoothing with Trend)")
            st.caption(
                "We use an exponential smoothing model with an additive trend. "
               
            )

            run_fc = st.button("Run Forecast", key="run_forecast")

            if run_fc:
                with st.spinner("Fitting model and generating forecast..."):
                    model = ExponentialSmoothing(ts, trend="add", seasonal=None)
                    fit = model.fit(optimized=True)

                    fc = fit.forecast(horizon)

                    # Ensure forecast years are future years (important for display)
                    last_year = int(ts.index.max())
                    fc_years = list(range(last_year + 1, last_year + horizon + 1))
                    fc.index = fc_years

                    out = pd.DataFrame({
                        "Year": list(ts.index) + list(fc.index),
                        "Series": ["Actual"] * len(ts) + ["Forecast"] * len(fc),
                        target: list(ts.values) + list(fc.values),
                    })

                # Table
                st.markdown("#### Actual vs Forecast (table)")
                st.dataframe(out.tail(15), use_container_width=True)

                # Plot
                fig_fc = go.Figure()

                actual = out[out["Series"] == "Actual"]
                forecast_df = out[out["Series"] == "Forecast"]

                fig_fc.add_trace(go.Scatter(
                    x=actual["Year"],
                    y=actual[target],
                    mode="lines+markers",
                    name="Actual"
                ))

                fig_fc.add_trace(go.Scatter(
                    x=forecast_df["Year"],
                    y=forecast_df[target],
                    mode="lines+markers",
                    name="Forecast",
                    line=dict(dash="dash")
                ))

                fig_fc.update_layout(
                    title=f"Actual vs Forecast — {format_company(symbol)}",
                    xaxis_title="Year",
                    yaxis_title=target.replace("_", " "),
                    template="plotly_dark",
                    hovermode="x unified"
                )

                if use_log_y:
                    fig_fc.update_yaxes(type="log")

                st.plotly_chart(fig_fc, use_container_width=True)

                with st.expander("Interpretation (simple)"):
                    st.write(
                        "The dashed line shows the forecasted values. This forecast is best used for short horizons. "
                        "If the series is non-stationary, forecasts primarily extend the recent trend pattern."
                    )