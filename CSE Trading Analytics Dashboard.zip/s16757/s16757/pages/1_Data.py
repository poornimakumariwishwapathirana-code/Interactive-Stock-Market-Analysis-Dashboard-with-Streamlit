import streamlit as st
import pandas as pd
import numpy as np
from data_loader import load_processed_data

st.markdown("""
<style>
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
div[data-testid="stMetric"] { background: rgba(255,255,255,0.03); padding: 12px; border-radius: 14px; }
</style>
""", unsafe_allow_html=True)

st.title("Data Overview")

# Load processed dataset (shared)
@st.cache_data
def get_df():
    return load_processed_data()

merged_df = get_df()



# --- Feature Engineering: Volatility ---
required_cols = ["High_(Rs)", "Low_(Rs)"]
if all(c in merged_df.columns for c in required_cols):
    merged_df["Volatility"] = (merged_df["High_(Rs)"] - merged_df["Low_(Rs)"]).abs()
else:
    st.warning("Volatility could not be created because 'High_(Rs)' or 'Low_(Rs)' is missing.")

#st.success("Final merged dataset created successfully.")

# -----------------------------
# Interactive Filtering
# -----------------------------
st.subheader("Interactive Data Filtering")

selected_sector = st.multiselect(
    "Select GICS Industry Group",
    options=merged_df['GICS Industry Group'].dropna().unique()
)

year_range = st.slider(
    "Select Year Range",
    min_value=int(merged_df['Year'].min()),
    max_value=int(merged_df['Year'].max()),
    value=(2006, 2022)
)

filtered_df = merged_df.copy()

if selected_sector:
    filtered_df = filtered_df[
        filtered_df['GICS Industry Group'].isin(selected_sector)
    ]

filtered_df = filtered_df[
    (filtered_df['Year'] >= year_range[0]) &
    (filtered_df['Year'] <= year_range[1])
]

st.dataframe(filtered_df, use_container_width=True)

# Download option
st.download_button(
    label="Download Filtered Dataset",
    data=filtered_df.to_csv(index=False),
    file_name="filtered_dataset.csv",
    mime="text/csv"
)

st.set_page_config(layout="wide")