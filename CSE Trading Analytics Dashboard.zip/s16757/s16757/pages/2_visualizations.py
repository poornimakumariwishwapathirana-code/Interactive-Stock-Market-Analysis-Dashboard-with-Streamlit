import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

from data_loader import load_processed_data

st.markdown("""
<style>
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
div[data-testid="stMetric"] { background: rgba(255,255,255,0.03); padding: 12px; border-radius: 14px; }
</style>
""", unsafe_allow_html=True)

st.set_page_config(page_title="Exploratory Insights", page_icon="📊", layout="wide")

st.title("Exploratory Insights")
st.caption("Interactive exploration of Colombo Stock Exchange annual trading statistics (2006–2022).")

@st.cache_data
def get_df():
    return load_processed_data()

df = get_df()

if df is None or not isinstance(df, pd.DataFrame):
    st.error("Dataset could not be loaded. Please check `data_loader.py`.")
    st.stop()

# Ensure Volatility exists
if "Volatility" not in df.columns and {"High_(Rs)", "Low_(Rs)"}.issubset(df.columns):
    df["Volatility"] = (df["High_(Rs)"] - df["Low_(Rs)"]).abs()

df = df.dropna(subset=["Symbol", "Year"]).copy()
df["Year"] = df["Year"].astype(int)



# -------------------------------
# Sidebar / Filters
# -------------------------------
st.sidebar.header("Filters")

year_min, year_max = int(df["Year"].min()), int(df["Year"].max())
year_range = st.sidebar.slider("Year range", year_min, year_max, (year_min, year_max))

if "GICS Industry Group" in df.columns:
    industries = sorted(df["GICS Industry Group"].dropna().unique().tolist())
    selected_industries = st.sidebar.multiselect("GICS Industry Group", industries, default=[])
else:
    selected_industries = []

metric_options = [c for c in ["Turnover(Rs)", "Trade_Volume", "Share_Volume", "Volatility"] if c in df.columns]
metric = st.sidebar.selectbox("Main metric", metric_options, index=0)

agg_choice = st.sidebar.selectbox("Aggregation for trends", ["Sum", "Mean"])

use_log = st.sidebar.checkbox("Log scale for y-axis (helps with skewness)", value=False)

# Apply filters
fdf = df[(df["Year"] >= year_range[0]) & (df["Year"] <= year_range[1])].copy()
if selected_industries:
    fdf = fdf[fdf["GICS Industry Group"].isin(selected_industries)]

# -------------------------------
# Company selection (up to 10)
# -------------------------------
st.sidebar.subheader("Company Comparison")

# Build labels: Symbol — Company Name
if "Company_Name" in fdf.columns:
    name_map = (
        fdf[["Symbol", "Company_Name"]]
        .dropna()
        .drop_duplicates("Symbol")
        .set_index("Symbol")["Company_Name"]
        .to_dict()
    )
else:
    name_map = {}

symbols = sorted(fdf["Symbol"].dropna().unique().tolist())

def fmt(sym):
    nm = name_map.get(sym, "")
    return f"{sym} — {nm}" if nm else sym

selected_companies = st.sidebar.multiselect(
    "Select up to 10 companies",
    options=symbols,
    format_func=fmt,
    default=[]
)

if len(selected_companies) > 10:
    st.sidebar.warning("Please select **10 companies or fewer**.")
    selected_companies = selected_companies[:10]

# -------------------------------
# KPI Row
# -------------------------------
with st.container(border=True):
    st.markdown("### Key Snapshot")

    k1, k2 = st.columns(2)

    k1.metric("Companies", f"{fdf['Symbol'].nunique():,}")
    k2.metric("Years", f"{fdf['Year'].nunique():,}")


    if fdf.empty:
        st.warning("No data available for the selected filters. Try expanding the year range or removing filters.")
        st.stop()

# =========================================================
# 1) Market Trend Over Time
# =========================================================
with st.container(border=True):
    st.markdown("## Market Trend Over Time")

    trend = fdf.groupby("Year")[metric]
    trend_df = trend.sum().reset_index(name="Value") if agg_choice == "Sum" else trend.mean().reset_index(name="Value")

    fig1 = px.line(
        trend_df,
        x="Year",
        y="Value",
        markers=True,
        title=f"{agg_choice} of {metric} by Year",
        template="plotly_dark"
    )
    fig1.update_layout(xaxis_title="Year", yaxis_title=metric)
    if use_log:
        fig1.update_yaxes(type="log")

    st.plotly_chart(fig1, use_container_width=True)

    st.write(
        "This plot displays the yearly trend of the selected metric (e.g., turnover or volume). Rising patterns indicate increasing market activity, while sudden spikes or drops may reflect economic shocks or major market events."
    )

# =========================================================
# 2) Industry Comparison
# =========================================================
with st.container(border=True):
    st.markdown("## Industry Comparison")

    if "GICS Industry Group" in fdf.columns:
        ind_df = (
            fdf.groupby("GICS Industry Group")[metric]
            .sum()
            .sort_values(ascending=False)
            .reset_index()
            .rename(columns={metric: "Total"})
        )

        top_n = st.slider("Show top industries", 5, min(25, len(ind_df)) if len(ind_df) > 5 else 5, 10)

        fig2 = px.bar(
            ind_df.head(top_n),
            x="GICS Industry Group",
            y="Total",
            title=f"Top {top_n} Industries by Total {metric}",
            template="plotly_dark"
        )
        fig2.update_layout(xaxis_title="GICS Industry Group", yaxis_title=f"Total {metric}")
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("Industry comparison is unavailable because GICS Industry Group is missing.")

    st.write(
        "Each bar represents an industry’s total contribution to the selected metric. Larger bars indicate industries with stronger trading activity and higher market influence."
    )

    # =========================================================
    # 3) Distribution + Outliers
    # =========================================================
with st.container(border=True):
    st.markdown("## Distribution and Outliers")

    cA, cB = st.columns(2)

    with cA:
        fig3a = px.histogram(
            fdf,
            x=metric,
            nbins=40,
            title=f"Distribution of {metric}",
            template="plotly_dark"
        )
        fig3a.update_layout(xaxis_title=metric, yaxis_title="Count")
        if use_log:
            fig3a.update_xaxes(type="log")
        st.plotly_chart(fig3a, use_container_width=True)

    with cB:
        fig3b = px.box(
            fdf,
            y=metric,
            points="all",  # shows points so you can hover outliers
            hover_data=["Year", "Symbol"] + (["Company_Name"] if "Company_Name" in fdf.columns else []),
            title=f"Boxplot of {metric} (Outliers)",
            template="plotly_dark"
        )
        fig3b.update_layout(yaxis_title=metric)
        if use_log:
            fig3b.update_yaxes(type="log")
        st.plotly_chart(fig3b, use_container_width=True)


    # Outlier table (IQR method)
    Q1 = fdf[metric].quantile(0.25)
    Q3 = fdf[metric].quantile(0.75)
    IQR = Q3 - Q1
    upper = Q3 + 1.5 * IQR
    lower = Q1 - 1.5 * IQR

    outliers = fdf[(fdf[metric] > upper) | (fdf[metric] < lower)].copy()

    st.write(
        "These plots show how values are spread across companies and years. "
        "If the histogram is heavily skewed and the boxplot shows many outliers, "
        "it means a small number of company-years dominate the market activity. "
        "This is why log transformations are often useful in financial data."
        )


    with st.expander("Show detected outliers (company-wise)"):
        cols = ["Year", "Symbol"] + (["Company_Name"] if "Company_Name" in outliers.columns else []) + [metric]
        st.dataframe(outliers[cols].sort_values(metric, ascending=False).reset_index(drop=True),
                    use_container_width=True)



# =========================================================
# 4) Relationship Plot (Turnover vs Volatility)
# =========================================================
with st.container(border=True):
    st.markdown("## Relationship Between Volatility and Market Activity")

    if "Volatility" in fdf.columns and "Turnover(Rs)" in fdf.columns:
        year_for_scatter = st.selectbox("Select a single year (optional)", ["All years"] + sorted(fdf["Year"].unique().tolist()))
        sdf = fdf.copy()
        if year_for_scatter != "All years":
            sdf = sdf[sdf["Year"] == int(year_for_scatter)]

            # Highlight selected companies
        sdf["Group"] = np.where(
        sdf["Symbol"].isin(selected_companies),
        "Selected Companies",
        "Companies"
    )
        fig4 = px.scatter(
        sdf,
        x="Volatility",
        y="Turnover(Rs)",
        color="Group",
        hover_data=["Year", "Symbol", "Company_Name"],
        template="plotly_dark"
    )
        fig4.update_layout(xaxis_title="Volatility (High - Low)", yaxis_title="Turnover (Rs)")
        if use_log:
            fig4.update_yaxes(type="log")
        st.plotly_chart(fig4, use_container_width=True)

        st.caption("Tip: select up to 10 companies from the sidebar to highlight them clearly in this plot.")

        
        st.write(
                "If points tend to rise as volatility increases, it suggests that higher uncertainty "
                "is associated with higher trading value (turnover). This visual supports the panel regression interpretation."
            )
    else:
        st.info("Relationship plot needs both Volatility and Turnover(Rs) columns.")

# =========================================================
# 5) Selected Companies Trend Comparison
# =========================================================
with st.container(border=True):
    st.markdown("## Trend Comparison over Companies")

    if selected_companies:
        comp_df = fdf[fdf["Symbol"].isin(selected_companies)].copy()
        comp_df["Company"] = comp_df["Symbol"].map(fmt)

        # Choose a metric for this comparison
        comp_metric = st.selectbox("Metric for company comparison", metric_options, index=0)

        comp_year = comp_df.groupby(["Year", "Company"], as_index=False)[comp_metric].mean()

        fig5 = px.line(
            comp_year,
            x="Year",
            y=comp_metric,
            color="Company",
            markers=True,
            title="Selected Companies — Trend Over Time",
            template="plotly_dark"
        )
        fig5.update_layout(xaxis_title="Year", yaxis_title=comp_metric)
        if use_log:
            fig5.update_yaxes(type="log")

        st.plotly_chart(fig5, use_container_width=True)
    else:
        st.info("Select 10 or less companies in the sidebar to compare them here.")