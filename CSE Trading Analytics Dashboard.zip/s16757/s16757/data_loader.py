import pandas as pd
import numpy as np
import streamlit as st

def load_processed_data():
    
    # -----------------------------
    # Load raw multi-sheet dataset
    # -----------------------------
    @st.cache_data
    def load_raw_data():
        df_dict = pd.read_excel(
            "data/Annual Trading Statistics.xlsx",
            sheet_name=None
        )
        return df_dict

    @st.cache_data
    def load_gics():
        return pd.read_excel("data/GICS.xlsx")

    df_dict = load_raw_data()
    gics_df = load_gics()

    # -----------------------------
    # Verify required years
    # -----------------------------
    expected_years = set(str(y) for y in range(2006, 2023))
    actual_years = set(df_dict.keys())
    missing_years = expected_years - actual_years

    st.subheader("Year Availability")

    if len(missing_years) == 0:
        st.success("Data available from 2006 to 2022.")
    else:
        st.error(f"Missing years: {missing_years}")

    # -----------------------------
    # Cleaning + Standardizing
    # -----------------------------
    for year, yearly_df in df_dict.items():
        yearly_df.columns = (
            yearly_df.columns
            .str.strip()
            .str.replace(' ', '_')
            .str.replace('.', '', regex=False)
            .str.replace('Close_Price_', 'Close_', regex=False)
        )

        yearly_df['Symbol'] = (
            yearly_df['Symbol']
            .astype(str)
            .str.strip()
            .str.upper()
        )

    # -----------------------------
    # Identify companies present in all years
    # -----------------------------
    company_sets = [
        set(yearly_df['Symbol'].dropna())
        for yearly_df in df_dict.values()
    ]

    companies_all_years = set.intersection(*company_sets)

    st.subheader("Consistent Longitudinal Companies")
    st.write(f"Total companies present in all years: **{len(companies_all_years)}**")

    # -----------------------------
    # Aggregation Dictionary
    # -----------------------------
    agg_dict = {
        'Company_Name': 'first',
        'Open_(Rs)': 'mean',
        'High_(Rs)': 'max',
        'Low_(Rs)': 'min',
        'Close_(Rs)': 'mean',
        'Trade_Volume': 'sum',
        'Share_Volume': 'sum',
        'Turnover(Rs)': 'sum'
    }

    # -----------------------------
    # Annual Aggregation
    # -----------------------------
    all_years_data = []

    for year, yearly_df in df_dict.items():

        annual_df = (
            yearly_df
            .groupby('Symbol', as_index=False)
            .agg(agg_dict)
        )

        annual_df = annual_df[
            annual_df['Symbol'].isin(companies_all_years)
        ]

        annual_df['Year'] = int(year)

        annual_df = annual_df.merge(
            gics_df,
            on='Symbol',
            how='left'
        )

        all_years_data.append(annual_df)

    merged_df = (
        pd.concat(all_years_data, ignore_index=True)
        .sort_values(['Year', 'Symbol'])
        .reset_index(drop=True)
    )

    return merged_df

    